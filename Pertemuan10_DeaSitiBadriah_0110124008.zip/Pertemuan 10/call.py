import operator
print()
print("## Penjumlahan ##")
operator.tambah(3,5)

print()
print("## Pengurangan ##")
operator.kurang(10,3)

print()
print("## Kali ##")
operator.kali(7,2)

print()
print("## Pembagian ##")
operator.bagi(12,3)

print()
print("## Pangkat ##")
operator.pangkat(4,2)


import bangundatar


print()
print("## Persegi ##")
bangundatar.l_Persegi(4)

print()
print("## Persegi ##")
bangundatar.l_persegipanjang(4,6)

print()
print("## Jajargenjang ##")
bangundatar.l_jajargenjang(15, 6)

print()
print("## Segitiga ##")
bangundatar.l_segitiga(6,6)

print()
print("## Lingkaran ##")
bangundatar.l_lingkaran(15)


import bangunruang

print()
print("## Kubus ##")
bangunruang.Kubus(6)

print()
print("## Balok ##")
bangunruang.balok(8, 5, 6)

print()
print("## Tabung ##")
bangunruang.tabung(6, 11)

print()
print("## Prisma ##")
bangunruang.prisma(4, 5, 9)

print()
print("## Limas ##")
bangunruang.limas(5, 8)